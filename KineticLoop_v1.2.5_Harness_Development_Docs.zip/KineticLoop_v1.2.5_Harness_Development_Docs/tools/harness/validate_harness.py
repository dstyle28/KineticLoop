#!/usr/bin/env python3
import json, hashlib, pathlib, sys, subprocess, fnmatch, argparse
ROOT=pathlib.Path(__file__).resolve().parents[2]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(n): return json.loads((ROOT/n).read_text())
def git(*args):
    r=subprocess.run(['git',*args],cwd=ROOT,text=True,capture_output=True)
    return r.returncode,r.stdout.strip(),r.stderr.strip()
def section(text, heading):
    marker=f"## {heading}"
    if marker not in text: return ''
    tail=text.split(marker,1)[1]
    return tail.split('\n## ',1)[0]
def bullets(s):
    return [ln[2:].strip() for ln in s.splitlines() if ln.startswith('- ')]
def matches(path, patterns):
    return any(fnmatch.fnmatch(path,p) or (p.endswith('/**') and path.startswith(p[:-3])) for p in patterns)

def semantic_result_errors(obj, name='result'):
    e=[]
    if obj.get('task_status')=='PASS' and obj.get('task_checks_status')!='PASS': e.append(f'{name}:pass-without-check-pass')
    if obj.get('task_status')=='PASS' and not obj.get('commands_run'): e.append(f'{name}:pass-empty-commands')
    for i,c in enumerate(obj.get('commands_run',[])):
        if c.get('result') in ('PASS','FAIL') and not c.get('evidence_ref'): e.append(f'{name}:command-evidence:{i}')
    for i,r in enumerate(obj.get('requirements_covered',[])):
        if r.get('status') in ('PASS','APPROVED_NA') and not r.get('evidence_ref'): e.append(f'{name}:requirement-evidence:{i}')
    return e

ap=argparse.ArgumentParser()
ap.add_argument('--protected-base', default=None, help='Git base ref used to reject normal feature-branch changes to frozen files/baseline.')
ap.add_argument('--reviewed-head', default=None, help='When supplied, prove reviewed_head..HEAD contains only review-record paths for --task-id.')
ap.add_argument('--task-id', default=None)
args=ap.parse_args()
errors=[]

# current index
idx=load('CURRENT_DOCUMENT_INDEX.json')
for e in idx['documents']+idx.get('machine_readable',[]):
    p=ROOT/e['path']
    if not p.exists(): errors.append(f"missing:{e['path']}")
    elif e.get('sha256') and sha(p)!=e['sha256']: errors.append(f"hash:{e['path']}")

# frozen protected content hashes in the current tree
base=load('FROZEN_BASELINE.json')
for e in base['files']:
    p=ROOT/e['path']
    if not p.exists() or sha(p)!=e['sha256']: errors.append(f"frozen:{e['path']}")

# protected Git base: changing frozen file OR its baseline in a normal feature PR is rejected
protected=args.protected_base
if protected:
    rc,out,err=git('diff','--name-only',f'{protected}...HEAD')
    if rc!=0: errors.append(f'git-base:{err or protected}')
    else:
        changed=set(out.splitlines()) if out else set()
        protected_paths={e['path'] for e in base['files']}|{'FROZEN_BASELINE.json'}
        bad=sorted(changed & protected_paths)
        for p in bad: errors.append(f'protected-baseline-change:{p}')

# task write-scope validation against the same Git base when task-id is supplied
if protected and args.task_id:
    # backlog loaded below; defer actual check until after tasks are available
    pass

# backlog + packet consistency + DAG
b=load('KineticLoop_Harness_Backlog_v0.2.json'); tasks={t['id']:t for t in b['tasks']}
if protected and args.task_id:
    task=tasks.get(args.task_id)
    if not task:
        errors.append(f'write-scope-unknown-task:{args.task_id}')
    elif task.get('write_paths_status')!='ENFORCEABLE':
        errors.append(f'write-scope-unrefined:{args.task_id}')
    else:
        rc,out,err=git('diff','--name-only',f'{protected}...HEAD')
        if rc!=0:
            errors.append(f'write-scope-git:{err}')
        else:
            allowed=list(task.get('write_paths',[]))+[
                f'docs/exec-plans/completed/{args.task_id}_RESULT.yaml',
                f'docs/exec-plans/completed/{args.task_id}_RESULT.json',
                f'docs/exec-plans/reviews/{args.task_id}/**'
            ]
            for path in [x for x in out.splitlines() if x]:
                if not matches(path,allowed): errors.append(f'write-scope:{args.task_id}:{path}')
for t in b['tasks']:
    packet=ROOT/'docs/exec-plans/active'/f"{t['id']}.md"
    if t['status']!='SUPERSEDED' and not packet.exists(): errors.append(f"packet:{t['id']}")
    if packet.exists():
        txt=packet.read_text()
        if t.get('task_identity') and t['task_identity'] not in txt: errors.append(f"packet-identity:{t['id']}")
        if t['title'] not in txt and t['status']!='SUPERSEDED': errors.append(f"packet-title:{t['id']}")
        if t['status']!='SUPERSEDED':
            # compare dependencies/checks for active packets
            depsec=section(txt,'Dependencies').split('### Conditional dependencies',1)[0]
            import re as _re
            pdeps=sorted(set(_re.findall(r'KL-[0-9]{3}[A-Z]?', depsec)))
            if set(pdeps)!=set(t.get('depends_on',[])): errors.append(f"packet-deps:{t['id']}")
            chksec=section(txt,'Checks required for this task PR')
            pchecks=bullets(chksec)
            if pchecks and set(pchecks)!=set(t.get('checks_required_for_this_task',[])): errors.append(f"packet-checks:{t['id']}")
            if t.get('write_paths_status')=='ENFORCEABLE':
                ws=section(txt,'Resource / write isolation')
                for wp in t.get('write_paths',[]):
                    if wp not in ws: errors.append(f"packet-write-path:{t['id']}:{wp}")
    for d in t.get('depends_on',[]):
        if d not in tasks: errors.append(f"unknown-dep:{t['id']}->{d}")
    for d in t.get('conditional_depends_on',[]):
        dep=d if isinstance(d,str) else d.get('task_id')
        if dep and dep not in tasks: errors.append(f"unknown-conditional-dep:{t['id']}->{dep}")
    if t.get('packet_refinement')=='READY_WHEN_DEPENDENCIES_AND_GATES_SATISFIED' and t.get('status')!='SUPERSEDED':
        if t.get('write_paths_status')!='ENFORCEABLE' and t['id'].startswith('KL-00'):
            errors.append(f"ready-write-scope-unrefined:{t['id']}")

ind={k:0 for k in tasks}; out={k:[] for k in tasks}
for k,t in tasks.items():
    for d in t.get('depends_on',[]): out[d].append(k); ind[k]+=1
q=[k for k,v in ind.items() if v==0]; seen=0
while q:
    k=q.pop(); seen+=1
    for n in out[k]:
        ind[n]-=1
        if ind[n]==0:q.append(n)
if seen!=len(tasks): errors.append('dag-cycle')
ids=[t.get('task_identity') for t in b['tasks']]
if len(ids)!=len(set(ids)): errors.append('task-identity-duplicate')
for t in b['tasks']:
    if t['status']=='SUPERSEDED' and t.get('packet_refinement')!='MUST_REFINE_BEFORE_READY': errors.append(f"superseded-ready-risk:{t['id']}")

# result/review semantic validation for any committed examples/artifacts present
for p in (ROOT/'docs/exec-plans/completed').glob('*_RESULT.json') if (ROOT/'docs/exec-plans/completed').exists() else []:
    try: errors.extend(semantic_result_errors(json.loads(p.read_text()), p.name))
    except Exception as ex: errors.append(f'result-parse:{p.name}:{ex}')

# review-record-only suffix validation
if args.reviewed_head:
    if not args.task_id: errors.append('review-suffix:task-id-required')
    else:
        rc,out,err=git('diff','--name-only',f'{args.reviewed_head}..HEAD')
        if rc!=0: errors.append(f'review-suffix-git:{err}')
        else:
            allowed=[f'docs/exec-plans/reviews/{args.task_id}/**','docs/exec-plans/reviews/index/**']
            for p in [x for x in out.splitlines() if x]:
                if not matches(p,allowed): errors.append(f'review-stale-change:{p}')

if errors:
    print('HARNESS_CHECK_FAIL')
    for e in errors: print(e)
    sys.exit(1)
print(f"HARNESS_CHECK_PASS tasks={len(tasks)} active={sum(t['status']!='SUPERSEDED' for t in b['tasks'])}")
