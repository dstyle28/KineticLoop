# Merge Gate v0.3

A task PR may merge only when:

1. hard prerequisites are merged and conditional prerequisites required by current launch/release scope are satisfied;
2. the task packet is refined and its DoD is satisfied;
3. every `checks_required_for_this_task` item is PASS on `tested_commit`;
4. related requirement obligations are reported separately; NOT_RUN/SKIPPED are never promoted to PASS;
5. frozen authority impact has been checked and protected-baseline validation passes;
6. GENERAL independent review is PASS for the reviewed implementation revision;
7. all risk-triggered specialist reviews are PASS for the reviewed implementation revision;
8. the committed result artifact conforms to `THREAD_RESULT.schema.json` and semantic checks;
9. no unresolved resource/write-set collision exists;
10. generated docs/contracts are updated only when their current source of truth changed;
11. if HEAD is newer than a review's `reviewed_head_sha`, the suffix is mechanically proven to contain only REVIEW_RECORD_ONLY paths allowed by `THREAD_REVIEW_CONTRACT.md`.

Any implementation/configuration/migration/test/contract change after a reviewed SHA invalidates that review. Appending the prescribed review artifact does not invalidate the review when the review-record-only diff check passes.

Merge state is recorded separately from task PASS. A review PASS is not a merge fact, and a merged task does not imply any covered product requirement is PASS.
