# Thread Review Contract v0.2

Every task receives an independent GENERAL review. Additional specialist review is required when the task touches the corresponding risk surface:

- frozen Protocol / T1–T8 / authorization semantics → PROTOCOL;
- PostgreSQL locks, fencing, idempotency, migration chain or coordination rows → DB_CONCURRENCY;
- remote AI context, provider/health data export, credentials, retention/redaction → SECURITY_DATA_BOUNDARY.

Review artifacts are committed under `docs/exec-plans/reviews/<TASK_ID>/<REVIEW_TYPE>.json` and conform to `THREAD_REVIEW.schema.json`.

## Reviewed revision and the review-record append exception

`reviewed_head_sha` is the implementation/result revision actually reviewed. Normally any implementation, configuration, migration, test, contract, or product-document change after that SHA makes the affected review `STALE`.

A narrow exception exists so the review can itself be persisted without invalidating itself: after `reviewed_head_sha`, commits may append or update only the following task-scoped review bookkeeping paths:

- `docs/exec-plans/reviews/<TASK_ID>/**`
- an integration-owned review index under `docs/exec-plans/reviews/index/**`, if present

These commits are called **REVIEW_RECORD_ONLY** commits. They MUST NOT modify application code, tests, migrations, contracts, task packets, requirement status, frozen files, or the task result payload. A mechanical merge-gate check must prove that `git diff --name-only <reviewed_head_sha>..HEAD` contains only allowed review-record paths. If any other path changes, the review is stale and must be rerun.

The task result is committed before review and is part of the reviewed revision. Do not mutate the result after review merely to copy the reviewed SHA; the review artifact itself is the authority for `reviewed_head_sha`.

`CHANGES_REQUIRED` findings are closed only by a new implementation revision and a new review artifact. Untracked comments do not close findings.
