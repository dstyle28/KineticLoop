# Harness Negative Test Matrix v0.1

KL-001 must implement executable fixtures proving the harness rejects at least:

1. `task_status: PASS` with `task_checks_status != PASS`;
2. PASS task with empty `commands_run`;
3. executed PASS/FAIL command without `evidence_ref`;
4. requirement obligation marked PASS without evidence;
5. APPROVED_NA without approval/evidence reference;
6. packet dependency/check/write-path drift from canonical backlog metadata;
7. unknown dependency or DAG cycle;
8. task marked READY while packet refinement/write scope is unresolved;
9. frozen Protocol/DB changed together with `FROZEN_BASELINE.json` on a normal feature branch;
10. review PASS followed by application/config/test/migration/contract change;
11. review PASS followed only by allowed task-scoped review-record append (this one must remain valid);
12. a task writing outside its declared implementation `write_paths` (excluding standardized task bookkeeping paths).

Each fixture records the expected validator exit code and diagnostic key. Positive fixtures must cover the matching valid forms.
